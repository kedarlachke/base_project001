module.exports = {
    semi: false,
    trailingComma: 'es5',
    singleQuote: true,
    printWidth: 80,
    tabWidth: 2,
    endOfLine: 'auto'
  }