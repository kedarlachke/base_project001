declare module '*.jpg'
