import React from 'react'
import './AddFabButton.css'
function AddFabButton() {
    return (
        <button className="add-fab-button">+</button>
    )
}

export default AddFabButton
